<template>
    <section class="aside">
        <dl>
            <dt></dt>
            <dd></dd>
        </dl>
    </section>
</template>

<script>
export default {
    data: function() {
        return {}
    },
    methods: {

    }
}
</script>
<style scoped>

</style>
