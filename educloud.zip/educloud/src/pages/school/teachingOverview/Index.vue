<template>
    <div>
        <header-public></header-public>
        <div class='container'>
            学校总览
        </div>
    </div>
</template>

<script>
    import HeaderPublic from "@/components/header";
    export default {
        name: "schoolOverview",
        components: {
            HeaderPublic
        },
        methods: {

        }
     };
</script>


<style lang='stylus' scoped>

</style>
